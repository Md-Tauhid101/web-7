// const nav = document.querySelectorAll(".nav");

// nav.forEach(nav => {
//     const navbar = nav.querySelector(".navbar");

//     nav.addEventListener('click', () => {
//         navbar.classList.toggle('active');
//     })
// })

window.onload = function(){
    const icon = document.querySelector(".icon");
    const openIcon = document.querySelector('#open-icon');

    icon.addEventListener('click', () => {
        icon.classList.add('.open')
    })



}